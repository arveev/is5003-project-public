const greeting = () => {
  return agent => {
    let message = `Hey! I'm Llama Bot, and I can help you plan a good trip. To begin, can you tell me about your goals for this trip?`;
    agent.add(message);
  };
};

module.exports = greeting;
