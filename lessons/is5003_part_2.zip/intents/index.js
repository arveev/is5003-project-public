module.exports = {
  greeting: require('./greeting'),
  defaultFallback: require('./defaultFallback')
};
