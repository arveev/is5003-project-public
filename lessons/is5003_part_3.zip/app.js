'use strict';

const { WebhookClient } = require('dialogflow-fulfillment');
const bodyParser = require('body-parser');
const cors = require('cors');
const compression = require('compression');
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware');

var express = require('express');
const app = express();
const router = express.Router();

router.use(compression());
router.use(cors());
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));
router.use(awsServerlessExpressMiddleware.eventContext());

const intents = require('./intents');

router.post('/', (request, response) => {
  const agent = new WebhookClient({ request, response });
  const { headers, body } = request;

  let intentMap = new Map();
  intentMap.set('Greeting', intents.greeting());
  intentMap.set('Default Fallback', intents.defaultFallback());
  agent.handleRequest(intentMap);
});

app.use('/', router);

module.exports = app;
