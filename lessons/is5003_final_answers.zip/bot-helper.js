const getUserId = agent => {
  if (agent.originalRequest.hasOwnProperty('source')) {
    switch (agent.originalRequest.source) {
      case 'facebook':
        return agent.originalRequest.payload.data.sender.id;
      case 'twilio': // whatsapp
        return agent.originalRequest.payload.data.From;
      case 'google':
        return agent.originalRequest.payload.conversation.conversationId;
      default:
        return 'console';
    }
  }
  return null;
};

module.exports = {
  getUserId
};
