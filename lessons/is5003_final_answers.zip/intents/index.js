module.exports = {
  greeting: require('./greeting'),
  defaultFallback: require('./defaultFallback'),
  travelMotivation: require('./travelMotivation')
};
